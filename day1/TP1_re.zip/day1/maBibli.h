#ifndef MABIBLI_H
#define MABIBLI_H

int somme(int n, int* T);
int produit(int n, int* T);


#endif
