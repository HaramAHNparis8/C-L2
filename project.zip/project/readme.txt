pour compiler taper make ensuit taper ./sudoku
AHN Haram L2 group - A
puzzle.c fontionne pour initiliser et alluer structure de sudoku
setUpPuzzle creer la et allumer les tableaux transférés
box.c sert à trouver la solution

row.c sert à trouver la solution.
j'ai essayé mais je ne comprends pas pourquoi mon programme ne cherche pas tous les solution.
